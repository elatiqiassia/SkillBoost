# Skill_Boost
 Chatbot pour le développement de compétences professionnelles.

Ce projet est un chatbot conçu pour aider les utilisateurs à développer leurs compétences professionnelles dans deversité des domaines comme developpement web ,Design,
digital marketing...etc
Le chatbot utilise des techniques d'apprentissage automatique pour fournir des recommandations personnalisées et des conseils pratiques aux utilisateurs.



<Fonctionnalités>

Le chatbot propose les fonctionnalités suivantes :

Recommandations personnalisées : En fonction des réponses de l'utilisateur,
le chatbot fournit des recommandations personnalisées pour développer ses compétences professionnelles.

Conseils pratiques : Le chatbot propose des conseils pratiques pour aider l'utilisateur à mettre en pratique les compétences qu'il souhaite développer.

<Utilisation>

Pour utiliser le chatbot, il suffit de cloner le projet sur votre machine locale et d'exécuter le fichier principal. 
Vous aurez également besoin d'instaler les dépendances nécessaires pour exécuter le projet,
et d'importer le fichier onlinebot.sql dans votre base de donnée
  
 
<Développement>

Le chatbot a été développée en utilisant Html, css, JQUERY,Ajax et mysql 
